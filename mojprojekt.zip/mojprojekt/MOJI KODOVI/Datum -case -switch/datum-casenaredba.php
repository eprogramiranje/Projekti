<!DOCTYPE html>
<html>
<head>
  <title>Datum case naredba </title>
</head>
<body>

<?php


$mjesecudatumu=date('m');
switch ($mjesecudatumu)
{
    case 1 :
       $mjesecudatumu='Januar' ;
        break;
    case 2 :
       $mjesecudatumu='Februar' ;
    	break;
	case 3 :
       $mjesecudatumu='Mart' ;
        break;
    case 4 :
       $mjesecudatumu='April' ;
    	break;
	case 5 :
       $mjesecudatumu='Maj' ;
        break;
    case 6 :
       $mjesecudatumu='Jun' ;
        break;
    case 7 :
       $mjesecudatumu='Jul' ;
        break;
    case 8 :
       $mjesecudatumu='Avgust' ;
    	break;
	case 9 :
       $mjesecudatumu='Septembar' ;
        break;
    case 10 :
       $mjesecudatumu='Oktobar' ;
    	break;
	case 11 :
       $mjesecudatumu='Novembar';
        break;
    case 12 :
       $mjesecudatumu='Decembar' ;
        break;
}

echo '<P> Danas je '. date('d.m.Y') .' '.date('H:i'); // datum i vreme u formatu 16.10.2017 23:37


echo '<P> Danas je '. date('d').'. '.$mjesecudatumu.' '.date('Y').' '.date('H:i');


echo '<P> Narudžba procesuirana  '. date('d').'. '.$mjesecudatumu.'a '.date('Y').'. u '.date('H:i');

 ?>




</body>
</html>
