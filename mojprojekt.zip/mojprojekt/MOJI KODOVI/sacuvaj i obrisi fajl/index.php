<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>

<form method="post" action="index.php">
<input type="text" name = "Ime" placeholder="Ime" />
<input type="text" name = "Prezime" placeholder="Prezime" /><br>
<p> Odaberite proizvod koji zelite kupiti : </p>
<input type="checkbox" name="Artikal1" value="Hrana za Mače"><label> Hrana za mačke </label><br>
<input type="checkbox" name="Artikal2" value="Hrana za Pse"><label> Hrana za Pse </label><br><br>
<input type="submit" name="kreiraj" value="Kreiraj Naružbu" /> 
<input type="submit" name="pogledaj" value="Pogledaj Narudžbu" />
<input type="submit" name="obrisi" value="Obrši Narudžbu" />
</form>





   
<?php 

if (isset($_POST["kreiraj"])) // Ako je pritisnut submit sa name kreiraj  
{


@$artikli=$_POST["Artikal1"]."\n".$_POST["Artikal2"];

$podatak_za_pisanje_u_datoteku =

"Naručio je ". $_POST["Ime"]." ".$_POST["Prezime"]. "\n"

."Sadržaj naudzbe : \n ".$artikli."\n"

."Narudžba procesuirana " . date('d.m.Y') ." u ".date('H:i')."\n\n"; // datum



$datoteka = fopen("narudzba.txt", 'ab');
// otvara datoteku imena proba.txt i dodaje upisivanje ab
if(!$datoteka)
{
    echo('Neuspjelo otvarnje');// ako nije uspio otvorit
}
else {

fwrite($datoteka, $podatak_za_pisanje_u_datoteku);
// funkcija upisuje u datoteku , podatak 
fclose($datoteka); // zatvara datoteku
    }

} else if (isset($_POST["obrisi"])){ // ako je submit obriši 

@unlink("Narudzba.txt");// brise datoteku narudzba.txt
}
else if (isset($_POST["pogledaj"])) // ako je submit pogledaj

{


$ime = "narudzba.txt";  // deklaracija varijable za lokaciju datoteke
$datoteka = fopen($ime, 'r');// otvara za čitanje
$podaci = fread($datoteka, filesize($ime)); // podaci procitani iz datoteke
fclose($datoteka); // zatvara datoteku

ECHO $podaci;





}





 ?>

</body>
</html>