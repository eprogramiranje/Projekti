//google translate funkcija 
function googleSectionalElementInit() {
      new google.translate.SectionalElement({
        sectionalNodeClassName: "translate",
        controlNodeClassName: "translate_control",
        background: "#f4fa58"
      }, "google_sectional_element");
    }

// kad je dokument ucitan 
$(document).ready(function(){
 
 // po isteku klikce na skriveni link u css
setTimeout(function(){ 
 $('a.goog-te-gadget-link')[0].click(); 
   }, 550);



});