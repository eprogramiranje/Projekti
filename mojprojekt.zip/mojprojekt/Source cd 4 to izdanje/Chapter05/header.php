<html>
<head>
  <title>TLA Consulting Pty Ltd</title>
  <style type="text/css">
    h1 {color:white; font-size:24pt; text-align:center;
        font-family:arial,sans-serif}
    .menu {color:white; font-size:12pt; text-align:center;
           font-family:arial,sans-serif; font-weight:bold}
    td {background:black}
    p {color:black; font-size:12pt; text-align:justify;
       font-family:arial,sans-serif}
    p.foot {color:white; font-size:9pt; text-align:center;
            font-family:arial,sans-serif; font-weight:bold}
    a:link,a:visited,a:active {color:white}
  </style>
</head>
<body>

  <!-- page header -->
  <table width="100%" cellpadding="12" cellspacing="0" border="0">
  <tr bgcolor="black">
    <td align="left"><img src="logo.gif" alt="TLA logo" height=70 width=70></td>
    <td>
        <h1>TLA Consulting</h1>
    </td>
    <td align="right"><img src="logo.gif" alt="TLA logo" height=70 width=70></td>
  </tr>
  </table>

  <!-- menu -->
  <table width="100%" bgcolor="white" cellpadding="4" cellspacing="4">
  <tr >
    <td width="25%">
      <img src="s-logo.gif" alt="" height=20 width=20> <span class="menu">Home</span></td>
    <td width="25%">
      <img src="s-logo.gif" alt="" height=20 width=20> <span class="menu">Contact</span></td>
    <td width="25%">
      <img src="s-logo.gif" alt="" height=20 width=20> <span class="menu">Services</span></td>
    <td width="25%">
      <img src="s-logo.gif" alt="" height=20 width=20> <span class="menu">Site Map</span></td>
  </tr>
  </table>

