<?php

 phpinfo();

?>
