/*

radi po principu 

$(selektor).akcija(funkcija_kojaseizvsi(argumentifunkcije)
{
	
	telo i naredbe funkcije 
}

);

selektori :

ako selektujemo klasu upisujemo ".imeklase" 
ako id upisujemo "#imeid-a"
ako dodajemo  tag samo ime taga "tag"- ovo ce selektovat sve tagove tog imena
ako treba pristupit nekom tagu kao pojedinacnom pri čemu on nema ni id ni klasu
to mozemo ucinit tako sto cemo pristupit najblizem tagu u istom nivou i dodavat
funkcije .next za napred ili .parent za nazad
primer za toje :

$("body").next().next().click();

$("#idelementa").parent().click();

ovo radi za iste nivoe ako je nesto ugnjezdeno pristupa mu se znakom ">"  primer tag1 > ugnjezdenitag
$("body>div>p") ili ako ima vise istih imena  $("ul>li:first-child") i onda dodajes .next ...



.eq(3)      - bira četvrti element po redu koji ima  naziv taga ,ili clase u dokumentu 
              primer $("button").eq(3).click();
              element je cetvrti jer pozicioniranje ide 0,1,2,3,4 ... 

.Find();    - trazi odredjeni tag ili id ili klasu u ugnjezdenoj  selekciji  
              primer $("ul").find('a').css('color','red'); - ovo dodaje css boju na link a unutar ul taga

.Append();       - Dodaje tekst u postojeci element na kraju elementa(nemenja sadrzaj)
.HTML();         - Dodaje tekst u obliku htmla- pri cemu brise postojeci html.
.addClass();     - Dodaje klasu na element
.removeClass();  - Briše klasu sa elementa 
.toggleClass();  - dodaje i ponovnim klikom brise klasu  primer $("h1, h2, p").toggleClass("blue"); 
.CSS();          - Dodaje vrednost css na element primer $("ul").css('color','red');
.val();          - Dodaje ili uzima vrednost Value na elementima poput input
.text();         - uzima ili upisuje text u sadrzaj elementa
.attr();         - postavlja ili uzima atribut primer alert($("#w3s").attr("href"));
   

.draggable();  - dozvoljava pomeranje elementa kad kliknes na njega
      

.Click();      -  klikće
.dblClicK();   - Dupli klik
.mouseenter()  - U koliko je miš unutar granica elementa
.mouseleave()  - Kada miš napusti element
.Hide();       - sakri element  ima svojstvo  .Hide(speed,callback)  speed je 2000 ms a callback povratna funkcija
.Show();       - prikazuje element koji ima css displey:none;  isto ko i hide ima speed i callback
.toggle();     - Ako je skriveno prikazuje ako je prikazano sakriva (ima svojstva speed i callback)
.fadeIn();     - prikaži sa efektom iz magle ( takodje ima svojstva speed ,callback)
.fadeOut()     - sakri sa efektom iz magle ( takodje ima svojstva speed ,callback)
.fadetoggle(); - prikazi / sakri( efekti izmagljivanja ima svojstva speed i callback)
















*/



// kada je dokument ucitan
jQuery(document).ready(function() {
//ako  klikes  na sve  elemente klase "prvi" 
//kod unosa klase se koristi oblik .classs u ovom slucaju ".prvi"	
$(".prvi").click(function() {
// dodaje tekst <br><p> ovo je moj paragraf</p> u sve elemente klase "prvi"
// u ovom slucaju je dodano u sam button
$(".prvi").append("<br><p> ovo je moj dodan tekst</p>");
});


// ako kliknens na  element sa id=prvi
//kod unosa id-a koristi se oblik #id u ovom slucaju "#prvi"
$("#prvi").click(function(){
// kada za akciju koristimo .html nakon unosa se sav prethodni html kod u tom
//elementu menja sadzajem  novog koda u ovom slucaju  "neki tekst"
// znaci u izmeni bodi taga bih se izmenio sav html u samom body tagu	
$("#html-sakri").html("neki tekst");
// u ovom slucaju function() izvrsava setTimeout funkciu 
//koja poziva na izvrsenje function() unutar sebe ali  isteku 2000 ms
setTimeout(function(){
//kod koji izvrsava function() u obvom slucaju sakriva paragraf sa id - html/sakri
$("#html-sakri").hide();

}, 2000);







});













});